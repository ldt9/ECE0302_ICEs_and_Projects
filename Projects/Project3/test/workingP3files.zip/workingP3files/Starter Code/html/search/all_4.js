var searchData=
[
  ['frequencyelementname',['frequencyElementName',['../class_x_m_l_parser.html#a39f898708b8586565aa8bccd4c9b201b',1,'XMLParser']]]
];
